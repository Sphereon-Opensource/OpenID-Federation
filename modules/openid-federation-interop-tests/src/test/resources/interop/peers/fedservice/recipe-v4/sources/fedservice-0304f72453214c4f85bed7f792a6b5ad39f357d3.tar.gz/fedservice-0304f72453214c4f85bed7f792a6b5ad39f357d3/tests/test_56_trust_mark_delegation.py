import os
from urllib.parse import urlparse

import pytest
import responses
from cryptojwt import JWT
from cryptojwt.jws.jws import factory
from cryptojwt.key_jar import build_keyjar
from idpyoidc.client.defaults import DEFAULT_KEY_DEFS

from fedservice.message import TrustMarkRequest
from tests import create_trust_chain_messages
from tests.build_federation import build_federation

TRUST_MARK_OWNERS_KEYS = build_keyjar(DEFAULT_KEY_DEFS)
TM_OWNERS_ID = "https://tm_owner.example.org"

SIRTIFI_TRUST_MARK_TYPE = "https://refeds.org/sirtfi"
MUSHROOM_TRUST_MARK_TYPE = "https://mushrooms.federation.example.com/arrosto/agreements"

BASE_PATH = os.path.abspath(os.path.dirname(__file__))

TA_ID = "https://ta.example.org"
TMI_ID = "https://tmi.example.org"
FE_ID = "https://fe.example.org"

FEDERATION_CONFIG = {
    TA_ID: {
        "federation_entity": {
            "subordinate": [TMI_ID, FE_ID],
            "preference": {
                "organization_name": "The example federation operator",
                "organization_uri": "https://ta.example.org",
                "contacts": "operations@ta.example.org",
            },
            "trust_mark_owners": {
                SIRTIFI_TRUST_MARK_TYPE: {'jwks': TRUST_MARK_OWNERS_KEYS.export_jwks(),
                                          'sub': TM_OWNERS_ID},
                MUSHROOM_TRUST_MARK_TYPE: {
                    'jwks': TRUST_MARK_OWNERS_KEYS.export_jwks(),
                    'sub': TM_OWNERS_ID
                }
            },
            "trust_mark_issuers": {
                SIRTIFI_TRUST_MARK_TYPE: [TMI_ID],
                MUSHROOM_TRUST_MARK_TYPE: []
            },
            "endpoint": ['entity_configuration', 'list', 'fetch', 'resolve'],
        }
    },
    TMI_ID: {
        "federation_entity": {
            "trust_anchors": [TA_ID],
            "authority_hints": [TA_ID],
            "trust_mark_entity": {
                "class": "fedservice.trust_mark_entity.entity.TrustMarkEntity",
                "kwargs": {
                    "trust_mark_specification": {
                        SIRTIFI_TRUST_MARK_TYPE: {"lifetime": 2592000},
                        MUSHROOM_TRUST_MARK_TYPE: {"lifetime": 2592000}
                    },
                    "trust_mark_db": {
                        "class": "fedservice.trust_mark_entity.FileDB",
                        "kwargs": {
                            SIRTIFI_TRUST_MARK_TYPE: "sirtfi",
                            MUSHROOM_TRUST_MARK_TYPE: "mushroom"
                        }
                    },
                    "endpoint": {
                        "trust_mark": {
                            "path": "trust_mark",
                            "class": "fedservice.trust_mark_entity.server.trust_mark.TrustMark",
                            "kwargs": {
                                "client_authn_method": [
                                    "private_key_jwt"
                                ],
                                "auth_signing_alg_values": [
                                    "ES256"
                                ]
                            }
                        },
                        "trust_mark_list": {
                            "path": "trust_mark_list",
                            "class":
                                "fedservice.trust_mark_entity.server.trust_mark_list.TrustMarkList",
                            "kwargs": {}
                        },
                        "trust_mark_status": {
                            "path": "trust_mark_status",
                            "class":
                                "fedservice.trust_mark_entity.server.trust_mark_status.TrustMarkStatus",
                            "kwargs": {}
                        }
                    }
                }
            }
        }
    },
    FE_ID: {
        "federation_entity": {
            "trust_anchors": [TA_ID],
            "authority_hints": [TA_ID],
            "services": ['entity_configuration', 'entity_statement', 'trust_mark_status']
        }
    }
}


@pytest.fixture()
def tm_receiver():
    return "https://entity.example.org"


@pytest.fixture()
def trust_mark_delegation(tm_receiver):
    _jwt = JWT(TRUST_MARK_OWNERS_KEYS, iss=TM_OWNERS_ID, sign_alg='RS256')
    return _jwt.pack({'sub': TMI_ID, "trust_mark_type": SIRTIFI_TRUST_MARK_TYPE},
                     jws_headers={"typ": "trust-mark-delegation+jwt"})


@pytest.fixture()
def mushroom_trust_mark_delegation(tm_receiver):
    _jwt = JWT(TRUST_MARK_OWNERS_KEYS, iss=TM_OWNERS_ID, sign_alg='RS256')
    return _jwt.pack({'sub': TMI_ID, "trust_mark_type": MUSHROOM_TRUST_MARK_TYPE},
                     jws_headers={"typ": "trust-mark-delegation+jwt"})


class TestTrustMarkDelegation():

    @pytest.fixture(autouse=True)
    def setup(self):
        federation = build_federation(FEDERATION_CONFIG)
        self.ta = federation[TA_ID]
        self.fe = federation[FE_ID]
        self.tmi = federation[TMI_ID]

    @pytest.fixture()
    def create_trust_mark(self, trust_mark_delegation, tm_receiver):
        self.tmi.server.trust_mark_entity.trust_mark_specification[SIRTIFI_TRUST_MARK_TYPE] = {
            "delegation": trust_mark_delegation}
        return self.tmi.server.trust_mark_entity.create_trust_mark(SIRTIFI_TRUST_MARK_TYPE, tm_receiver)

    @pytest.fixture()
    def create_mushroom_trust_mark(self, mushroom_trust_mark_delegation, tm_receiver):
        self.tmi.server.trust_mark_entity.trust_mark_specification[MUSHROOM_TRUST_MARK_TYPE] = {
            "delegation": mushroom_trust_mark_delegation}
        return self.tmi.server.trust_mark_entity.create_trust_mark(MUSHROOM_TRUST_MARK_TYPE, tm_receiver)

    def test_delegated_trust_mark(self, create_trust_mark):
        _trust_mark = create_trust_mark
        _jwt = factory(_trust_mark)
        assert 'delegation' in _jwt.jwt.payload()
        _delegation = factory(_jwt.jwt.payload()['delegation'])
        assert _delegation.jwt.payload()['iss'] == TM_OWNERS_ID
        assert _jwt.jwt.payload()['iss'] == TMI_ID
        assert _delegation.jwt.payload()['sub'] == TMI_ID

    def test_verify_trust_mark(self, create_trust_mark):
        _trust_mark = create_trust_mark

        # (1) verify signature and that it is still active
        # a) trust chain for trust mark issuer

        where_and_what = create_trust_chain_messages(self.tmi, self.ta)
        with responses.RequestsMock() as rsps:
            for _url, _jwks in where_and_what.items():
                rsps.add("GET", _url, body=_jwks,
                         adding_headers={"Content-Type": "application/json"}, status=200)

            verified_trust_mark = self.fe.function.trust_mark_verifier(
                trust_mark={'trust_mark': _trust_mark, 'trust_mark_type': SIRTIFI_TRUST_MARK_TYPE},
                trust_anchor=self.ta.context.entity_id)

        assert verified_trust_mark

        # The collector holds all entity statements/configurations that has been seen so far.
        _collector = self.fe.function.trust_chain_collector

        # Ask the trust mark issuer if the trust mark is still valid
        # get the metadata for the issuer. Should be cached
        tm_issuer_metadata = _collector.get_metadata(TMI_ID)

        service = self.fe.get_service('trust_mark_status')
        req = service.get_request_parameters(
            request_args={
                'trust_mark': _trust_mark,
            },
            fetch_endpoint=tm_issuer_metadata["federation_entity"][
                'federation_trust_mark_status_endpoint']
        )
        p = urlparse(req['url'])
        tmr = TrustMarkRequest().from_urlencoded(p.query)

        # The response from the Trust Mark issuer
        resp = self.tmi.server.endpoint['trust_mark_status'].process_request(tmr.to_dict())
        # It's actually a signed JWT
        assert isinstance(resp, str)

    def test_verify_mushroom_trust_mark(self, create_mushroom_trust_mark):
        _trust_mark = create_mushroom_trust_mark

        # (1) verify signature and that it is still active
        # a) trust chain for trust mark issuer

        where_and_what = create_trust_chain_messages(self.tmi, self.ta)
        with responses.RequestsMock() as rsps:
            for _url, _jwks in where_and_what.items():
                rsps.add("GET", _url, body=_jwks,
                         adding_headers={"Content-Type": "application/json"}, status=200)

            verified_trust_mark = self.fe.function.trust_mark_verifier(
                trust_mark={'trust_mark': _trust_mark, "trust_mark_type": SIRTIFI_TRUST_MARK_TYPE},
                trust_anchor=self.ta.context.entity_id)

        assert verified_trust_mark

    @pytest.fixture()
    def create_mushroom_trust_mark_sans_delegation(self, mushroom_trust_mark_delegation, tm_receiver):
        self.tmi.server.trust_mark_entity.trust_mark_specification[MUSHROOM_TRUST_MARK_TYPE] = {}
        return self.tmi.server.trust_mark_entity.create_trust_mark(MUSHROOM_TRUST_MARK_TYPE, tm_receiver)

    def test_verify_mushroom_trust_mark_not_delegated(self, create_mushroom_trust_mark_sans_delegation):
        _trust_mark = create_mushroom_trust_mark_sans_delegation

        # (1) verify signature and that it is still active
        # a) trust chain for trust mark issuer

        where_and_what = create_trust_chain_messages(self.tmi, self.ta)
        # Will not be looking for a trust chain
        # del where_and_what['https://tmi.example.org/.well-known/openid-federation']
        del where_and_what['https://ta.example.org/fetch']
        with responses.RequestsMock() as rsps:
            for _url, _jwks in where_and_what.items():
                rsps.add("GET", _url, body=_jwks,
                         adding_headers={"Content-Type": "application/json"}, status=200)

            verified_trust_mark = self.fe.function.trust_mark_verifier(
                trust_mark={'trust_mark': _trust_mark, "trust_mark_type": SIRTIFI_TRUST_MARK_TYPE},
                trust_anchor=self.ta.context.entity_id)

        assert verified_trust_mark is None
