# -*- coding: latin-1 -*-
import json
import os

import pytest
from cryptojwt.key_jar import build_keyjar

from idpyoidc.key_import import import_jwks
from idpyoidc.message.oidc import APPLICATION_TYPE_WEB
from idpyoidc.message.oidc import RegistrationRequest
from idpyoidc.server import Server
from idpyoidc.server.configure import OPConfiguration
from idpyoidc.server.cookie_handler import CookieHandler
from idpyoidc.server.oidc.authorization import Authorization
from idpyoidc.server.oidc.read_registration import RegistrationRead
from idpyoidc.server.oidc.registration import Registration
from idpyoidc.server.oidc.token import Token
from idpyoidc.server.oidc.userinfo import UserInfo
from tests import CRYPT_CONFIG
from tests import SESSION_PARAMS

BASEDIR = os.path.abspath(os.path.dirname(__file__))

KEYDEFS = [
    {"type": "RSA", "key": "", "use": ["sig"]},
    {"type": "EC", "crv": "P-256", "use": ["sig"]},
]

CLIENT_KEYJAR = build_keyjar(KEYDEFS)
CLIENT_ID = "client_1"


def key_setup(context, client_id, client_secret=""):
    client_keyjar = CLIENT_KEYJAR
    client_keyjar = import_jwks(client_keyjar, client_keyjar.export_jwks(private=True), client_id)

    context.keyjar.import_jwks(client_keyjar.export_jwks(issuer_id=client_id), issuer=client_id)

    if client_secret:
        client_keyjar.add_symmetric(client_id, client_secret, ["sig"])
        context.keyjar.add_symmetric(client_id, client_secret, ["sig"])

    return client_keyjar


COOKIE_KEY_DEFS = [
    {"type": "oct", "kid": "sig", "use": ["sig"]},
    {"type": "oct", "kid": "enc", "use": ["enc"]},
]

RESPONSE_TYPES_SUPPORTED = [
    ["code"],
    ["token"],
    ["id_token"],
    ["code", "token"],
    ["code", "id_token"],
    ["id_token", "token"],
    ["code", "token", "id_token"],
    ["none"],
]

CAPABILITIES = {
    "subject_types_supported": ["public", "pairwise", "ephemeral"],
    "grant_types_supported": [
        "authorization_code",
        "implicit",
        "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "refresh_token",
    ],
}

msg = {
    "client_id": "client_1",
    "application_type": APPLICATION_TYPE_WEB,
    "redirect_uris": [
        "https://client.example.org/callback",
        "https://client.example.org/callback2",
    ],
    "client_name": "My Example",
    "client_name#ja-Jpan-JP": "クライアント名",
    "subject_type": "pairwise",
    "token_endpoint_auth_method": "client_secret_basic",
    "jwks_uri": "https://client.example.org/my_public_keys.jwks",
    "userinfo_encrypted_response_alg": "RSA-OAEP",
    "userinfo_encrypted_response_enc": "A128CBC-HS256",
    "contacts": ["ve7jtb@example.org", "mary@example.org"],
    "request_uris": [
        "https://client.example.org/rf.txt#qpXaRLh_n93TT",
        "https://client.example.org/rf.txt",
    ],
    "post_logout_redirect_uri": "https://rp.example.com/pl",
}

CLI_REQ = RegistrationRequest(**msg)


class TestEndpoint(object):

    @pytest.fixture(autouse=True)
    def create_endpoint(self):
        conf = {
            "issuer": "https://example.com/",
            "httpc_params": {"verify": False, "timeout": 1},
            "token_handler_args": {
                "code": {"lifetime": 600, "kwargs": {"crypt_conf": CRYPT_CONFIG}},
                "token": {"lifetime": 600, "kwargs": {"crypt_conf": CRYPT_CONFIG}},
                "refresh": {"lifetime": 600, "kwargs": {"crypt_conf": CRYPT_CONFIG}},
            },
            "capabilities": CAPABILITIES,
            "keys": {"key_defs": KEYDEFS, "uri_path": "static/jwks.json"},
            "cookie_handler": {
                "class": CookieHandler,
                "kwargs": {"keys": {"key_defs": COOKIE_KEY_DEFS}},
            },
            "endpoint": {
                "registration": {
                    "path": "registration",
                    "class": Registration,
                    "kwargs": {"client_authn_method": ["none"]},
                },
                "registration_api": {
                    "path": "registration_api",
                    "class": RegistrationRead,
                    "kwargs": {"client_authn_method": ["bearer_header"]},
                },
                "authorization": {
                    "path": "authorization",
                    "class": Authorization,
                    "kwargs": {},
                },
                "token": {
                    "path": "token",
                    "class": Token,
                    "kwargs": {
                        "client_authn_method": [
                            "client_secret_post",
                            "client_secret_basic",
                            "client_secret_jwt",
                            "private_key_jwt",
                        ]
                    },
                },
                "userinfo": {"path": "userinfo", "class": UserInfo, "kwargs": {}},
            },
            "template_dir": "template",
            "session_params": SESSION_PARAMS,
        }
        server = Server(OPConfiguration(conf=conf, base_path=BASEDIR), cwd=BASEDIR)
        self.registration_endpoint = server.get_endpoint("registration")
        self.registration_api_endpoint = server.get_endpoint("registration_read")
        server.context.cdb["client_1"] = {
            "redirect_uris": [("https://example.com/cb", ""), ("https://example.com/2nd_cb", "")]
        }
        self.client_keyjar = key_setup(server.context, CLIENT_ID)

    def test_do_response(self):
        _req = self.registration_endpoint.parse_request(CLI_REQ.to_json())
        _resp = self.registration_endpoint.process_request(request=_req)
        msg = self.registration_endpoint.do_response(**_resp)
        assert isinstance(msg, dict)
        _msg = json.loads(msg["response"])
        assert _msg

        http_info = {
            "headers": {
                "authorization": "Bearer {}".format(
                    _resp["response_args"]["registration_access_token"]
                )
            }
        }

        _api_req = self.registration_api_endpoint.parse_request(
            {'client_id': _resp["response_args"]['client_id']}, http_info=http_info)
        assert set(_api_req.keys()) == {"client_id", "authenticated"}

        _info = self.registration_api_endpoint.process_request(request=_api_req)
        assert set(_info.keys()) == {"response_args"}
        assert _info["response_args"] == _resp["response_args"]

        _endp_response = self.registration_api_endpoint.do_response(_info)
        assert set(_endp_response.keys()) == {"response", "http_headers"}
        assert ("Content-type", "application/json") in _endp_response["http_headers"]
