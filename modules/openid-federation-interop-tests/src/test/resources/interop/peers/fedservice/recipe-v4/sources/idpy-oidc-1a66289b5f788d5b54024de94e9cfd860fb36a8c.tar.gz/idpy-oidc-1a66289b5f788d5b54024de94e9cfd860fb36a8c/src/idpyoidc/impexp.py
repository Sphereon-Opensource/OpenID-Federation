import base64
import inspect
import logging
from typing import Any
from typing import List
from typing import Optional

from cryptojwt.utils import importer
from cryptojwt.utils import qualified_name

# from idpyoidc.item import DLDict
from idpyoidc.message import Message
from idpyoidc.storage import DictType

VERBOSE = False
logger = logging.getLogger(__name__)

def fully_qualified_name(cls):
    return cls.__module__ + "." + cls.__class__.__name__


def type2cls(v):
    if isinstance(v, str):
        return ""
    elif isinstance(v, int):
        return 0
    elif isinstance(v, bool):
        return bool
    elif isinstance(v, bytes):
        return b""
    elif isinstance(v, dict):
        return {}
    elif isinstance(v, list):
        return []
    else:
        return None


class ImpExp:
    parameter = {}
    special_load_dump = {}
    init_args = []

    def __init__(self):
        pass

    def dump_attr(self, cls, item, exclude_attributes: Optional[List[str]] = None) -> dict:
        val = None
        if VERBOSE:
            logger.debug(f"dump_attr:: cls: {cls}, item: {item}")
        if cls in [None, 0, "", bool]:
            val = item
        elif cls == b"":
            val = f"BYTES:{base64.b64encode(item).decode('utf-8')}"
        elif cls == {} and isinstance(item, dict):
            val = {}
            for k, v in item.items():
                if k != "upstream_get":
                    if k == "class":
                        if isinstance(v, str):
                            val[k] = v
                        else:
                            val[k] = fully_qualified_name(v)
                    else:
                        val[k] = self.dump_attr(type2cls(v), v, exclude_attributes)
        elif cls == []:
            if isinstance(item, list):
                val = [self.dump_attr(type2cls(v), v, exclude_attributes) for v in item]
            else:
                val = [item]
        elif cls == "DICT_TYPE":
            if isinstance(item, dict):
                val = item
            else:
                if isinstance(item, DictType):  # item should be a class instance
                    val = {
                        "DICT_TYPE": {"class": fully_qualified_name(item), "kwargs": item.kwargs}
                    }
                else:
                    raise ValueError("Expected a DictType class")
        elif isinstance(item, Message):
            val = {qualified_name(item.__class__): item.to_dict()}
        elif cls == object:
            val = qualified_name(item)
        elif isinstance(cls, list):
            if len(cls) != 0:
                val = [self.dump_attr(cls[0], v, exclude_attributes) for v in item]
            else:
#                val = [self.dump_attr(type2cls(v), v, exclude_attributes) for v in item]
                val = []
                for v in item:
                    _type = type2cls(v)
                    val.append(self.dump_attr(_type, v, exclude_attributes))
        elif inspect.isclass(cls):
            if VERBOSE:
                logger.debug(f"class instance: {cls}")
            _dump = getattr(cls, "dump", None)
            if _dump:
                val = _dump(item, exclude_attributes=exclude_attributes)
            else:
                if isinstance(item, cls):
                    val = {qualified_name(cls): item.to_dict()}
                elif isinstance(item, dict):
                    val = {qualified_name(cls): item}
                else:
                    logger.error(f"Can't dump {item} as {cls}")
        elif isinstance(cls, dict):
            # {"": class_instance}
            val = {}
            for key, class_instance in item.items():
                _dump = getattr(class_instance, "dump", None)
                if _dump:
                    key_val = _dump(exclude_attributes=exclude_attributes)
                else:
                    if getattr(class_instance, "to_dict", None):
                        key_val = {qualified_name(type(class_instance)): class_instance.to_dict()}
                    elif isinstance(class_instance, dict):
                        key_val = {qualified_name(type(class_instance)): class_instance}
                    else:
                        logger.error(f"Can't dump {class_instance} as {qualified_name(type(class_instance))}")
                        key_val = None
                val[key] = {qualified_name(type(class_instance)): key_val}
        else:
            _dump = getattr(item, "dump", None)
            if _dump:
                val = _dump(exclude_attributes=exclude_attributes)
            elif isinstance(item, dict):
                val = item
            else:
                logger.error(f"Do not know how to dump: {item}")
                raise AttributeError()

        if VERBOSE:
            logger.debug(f"-> {val}")
        return val

    def dump(self, exclude_attributes: Optional[List[str]] = None) -> dict:
        _exclude_attributes = exclude_attributes or []
        info = {}
        for attr, cls in self.parameter.items():
            if attr in _exclude_attributes or attr in self.special_load_dump:
                continue

            item = getattr(self, attr, None)
            if item is None:
                continue

            info[attr] = self.dump_attr(cls, item, exclude_attributes)

        for attr, func in self.special_load_dump.items():
            item = getattr(self, attr, None)
            if item:
                if "dump" in func:
                    info[attr] = func["dump"](item, exclude_attributes=exclude_attributes)
                else:
                    cls = self.parameter[attr]
                    info[attr] = self.dump_attr(cls, item, exclude_attributes)

        return info

    def local_load_adjustments(self, **kwargs):
        pass

    def load_attr(
            self,
            cls: Any,
            item: Any,
            init_args: Optional[dict] = None,
            load_args: Optional[dict] = None,
    ) -> Any:
        if load_args:
            _kwargs = {"load_args": load_args}
        else:
            _kwargs = {}

        if init_args:
            _kwargs["init_args"] = init_args

        if cls in [None, 0, "", bool]:
            if cls == "" and item.startswith("BYTES:"):
                val = base64.b64decode(item[len("BYTES:"):].encode("utf-8"))
            else:
                val = item
        elif cls == b"":
            val = base64.b64decode(item[len("BYTES:"):].encode("utf-8"))
        elif cls == {}:
            val = {k: self.load_attr(type2cls(v), v, init_args, load_args) for k, v in item.items()}
        elif cls == []:
            val = [self.load_attr(type2cls(v), v, init_args, load_args) for v in item]
        elif cls == "DICT_TYPE":
            if list(item.keys()) == ["DICT_TYPE"]:
                _spec = item["DICT_TYPE"]
                val = importer(_spec["class"])(**_spec["kwargs"])
            else:
                val = item
        elif cls == object:
            val = importer(item)
        elif isinstance(cls, list):
            if isinstance(cls[0], str):
                _cls = importer(cls[0])
            else:
                _cls = cls[0]

            if issubclass(_cls, ImpExp) and init_args:
                _args = {k: v for k, v in init_args.items() if k in _cls.init_args}
            else:
                _args = {}

            val = [_cls(**_args).load(v, **_kwargs) for v in item]
        elif isinstance(cls, dict):
            val = {}
            for key,value in item.items():
                # value is a dict
                for _cls_name, claims in value.items():
                    val[key] = importer(_cls_name)(**claims)
        elif issubclass(cls, Message):
            _cls_name = list(item.keys())[0]
            try:
                _cls = importer(_cls_name)
            except Exception as err:
                logger.error(f"Could not import {item}: {err}")
                raise
            val = _cls().from_dict(item[_cls_name])
        else:
            if issubclass(cls, ImpExp) and init_args:
                _args = {k: v for k, v in init_args.items() if k in cls.init_args}
            else:
                _args = {}

            if item:
                val = cls(**_args).load(item, **_kwargs)
            else:
                val = cls(**_args)

        return val

    def load(self, state: dict, init_args: Optional[dict] = None, load_args: Optional[dict] = None):
        """
        Loads a state into this instance.

        :param state: The state description
        :param init_args: Arguments that should be loaded at the beginning.
        :param load_args: Arguments used for the local adjustment of attributes
        :return:
        """
        if load_args:
            _kwargs = {"load_args": load_args}
            _load_args = load_args
        else:
            _kwargs = {}
            _load_args = {}

        if init_args:
            for attr, val in init_args.items():
                if attr in self.init_args:
                    setattr(self, attr, val)

        _kwargs["init_args"] = init_args

        for attr, cls in self.parameter.items():
            if attr not in state or attr in self.special_load_dump:
                continue

            _cls_init_args = getattr(cls, "init_args", {})

            for param, target in {"upstream_get": "unit_get", "conf": "conf",
                                  "token_handler_args": "token_handler_args"}.items():
                target_val = getattr(self, target, None)
                if not target_val:
                    continue

                if param in _cls_init_args and param not in _kwargs:
                    if _kwargs["init_args"] is None:
                        _kwargs["init_args"] = {param: target_val}
                    else:
                        _kwargs["init_args"][param] = target_val

            setattr(self, attr, self.load_attr(cls, state[attr], **_kwargs))

        for attr, func in self.special_load_dump.items():
            if attr in state:
                if "load" in func:
                    setattr(self, attr, func["load"](state[attr], **_kwargs))
                else:
                    cls = self.parameter[attr]
                    setattr(self, attr, self.load_attr(cls, state[attr], **_kwargs))

        self.local_load_adjustments(**_load_args)
        return self

    def flush(self):
        """
        Reset the content of the instance to its pristine state

        :return: A reference to the instance itself
        """
        for attr, cls in self.parameter.items():
            if cls is None:
                setattr(self, attr, None)
            elif cls == 0:
                setattr(self, attr, 0)
            elif cls is bool:
                setattr(self, attr, False)
            elif cls == "":
                setattr(self, attr, "")
            elif cls == []:
                setattr(self, attr, [])
            elif cls == {}:
                setattr(self, attr, {})
            else:
                setattr(self, attr, None)
        return self
