import logging

from cryptojwt.utils import importer

from idpyoidc.client.client_auth import CLIENT_AUTHN_METHOD
from idpyoidc.client.oauth2.utils import set_request_object
from idpyoidc.client.service import Service
from idpyoidc.message import Message
from idpyoidc.message.oauth2 import JWTSecuredAuthorizationRequest
from idpyoidc.server.util import execute
from idpyoidc.util import instantiate

logger = logging.getLogger(__name__)

HTTP_METHOD = "POST"


def push_authorization(context, request_args: Message, service: Service, **kwargs):
    """
    :param request_args: All the request arguments as a AuthorizationRequest instance
    :param service: The service to which this post construct method is applied.
    :param kwargs: Extra keyword arguments.
    """

    method_args = context.add_on["pushed_authorization"]
    logger.debug(f"PAR method args: {method_args}")
    logger.debug(f"PAR kwargs: {kwargs}")

    # Add client authentication if needed
    _headers = {}
    authn_method = method_args["authn_method"]
    if authn_method:
        if isinstance(authn_method, str):
            if authn_method not in context.client_authn_methods:
                context.client_authn_methods[authn_method] = CLIENT_AUTHN_METHOD[authn_method]()
        else:
            _name = ""
            for _name, spec in authn_method.items():
                if _name not in context.client_authn_methods:
                    context.client_authn_methods[_name] = execute(spec)
            authn_method = _name

        _args = kwargs.copy()
        if context.issuer:
            _args["iss"] = context.issuer

        _headers = service.get_headers(
            context, request_args, http_method=HTTP_METHOD, authn_method=authn_method, **_args
        )
        _headers["Content-Type"] = "application/x-www-form-urlencoded"

    if isinstance(request_args, Message):
        _required_params = request_args.to_dict()
    else:
        _required_params = request_args

    _add_request_object = kwargs.get("add_request_object", False)
    if _add_request_object:
        _required_params["request"] = set_request_object(service, request_args)

    _req = service.msg_type(**_required_params)
    _body = _req.to_urlencoded()

    _http_client = method_args.get("http_client", None)
    if not _http_client:
        _http_client = service.upstream_get("unit").httpc

    _httpc_params = service.upstream_get("unit").httpc_params
    _par_endpoint = kwargs.get("pushed_authorization_request_endpoint", None)
    if not _par_endpoint:
        _par_endpoint = context.provider_info["pushed_authorization_request_endpoint"]

    # Send it to the Pushed Authorization Request Endpoint using POST
    resp = _http_client(
        method=HTTP_METHOD,
        url=_par_endpoint,
        data=_body,
        headers=_headers,
        **_httpc_params
    )

    if resp.status_code == 200:
        _resp = Message().from_json(resp.text)
        _req = JWTSecuredAuthorizationRequest(request_uri=_resp["request_uri"])
        for param in request_args.required_parameters():
            _req[param] = request_args.get(param)
        request_args = _req
    else:
        raise ConnectionError(f"Could not connect to {_par_endpoint}")

    return request_args


def add_support(
        context,
        services,
        http_client=None,
        authn_method="",
):
    """
    Add the necessary pieces to support Pushed authorization.

    :param http_client: Specification for a HTTP client to use different from the default
    :param authn_method: The client authentication method to use
    :param services: A dictionary with all the services the client has access to.
    """

    if http_client is not None:
        if isinstance(http_client, dict):
            if "class" in http_client:
                http_client = instantiate(http_client["class"], **http_client.get("kwargs", {}))
            else:
                http_client = importer(http_client["function"])
        else:
            http_client = importer(http_client)

    _service = services["authorization"]  # There must be such a service
    context.add_on["pushed_authorization"] = {
        "http_client": http_client,
        "authn_method": authn_method,
    }

    _service.post_construct.append(push_authorization)
