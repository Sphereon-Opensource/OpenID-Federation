import logging
from typing import Optional

from idpyoidc.message import Message
from idpyoidc.message.oidc import RegistrationRequest
from idpyoidc.message.oidc import RegistrationResponse

logger = logging.getLogger(__name__)

REGISTER2PREFERRED = {
    # "require_signed_request_object": "request_object_algs_supported",
    "request_object_signing_alg": "request_object_signing_alg_values_supported",
    "request_object_encryption_alg": "request_object_encryption_alg_values_supported",
    "request_object_encryption_enc": "request_object_encryption_enc_values_supported",
    "userinfo_signed_response_alg": "userinfo_signing_alg_values_supported",
    "userinfo_encrypted_response_alg": "userinfo_encryption_alg_values_supported",
    "userinfo_encrypted_response_enc": "userinfo_encryption_enc_values_supported",
    "id_token_signed_response_alg": "id_token_signing_alg_values_supported",
    "id_token_encrypted_response_alg": "id_token_encryption_alg_values_supported",
    "id_token_encrypted_response_enc": "id_token_encryption_enc_values_supported",
    "default_acr_values": "acr_values_supported",
    "subject_type": "subject_types_supported",
    "token_endpoint_auth_method": "token_endpoint_auth_methods_supported",
    "response_types": "response_types_supported",
    "response_modes": "response_modes_supported",
    "grant_types": "grant_types_supported",
    # In OAuth2 but not in OIDC
    "scope": "scopes_supported",
    "token_endpoint_auth_signing_alg": "token_endpoint_auth_signing_alg_values_supported",
    # "display": "display_values_supported",
    # "claims": "claims_supported",
    # "request": "request_parameter_supported",
    # "request_uri": "request_uri_parameter_supported",
    # 'claims_locales': 'claims_locales_supported',
    # 'ui_locales': 'ui_locales_supported',
}

PREFERRED2REGISTER = dict([(v, k) for k, v in REGISTER2PREFERRED.items()])

REQUEST2REGISTER = {
    "client_id": "client_id",
    "client_secret": "client_secret",
    #    'acr_values': "default_acr_values" ,
    #    'max_age': "default_max_age",
    "redirect_uri": "redirect_uris",
    "response_type": "response_types",
    "request_uri": "request_uris",
    "grant_type": "grant_types",
    "scope": "scopes_supported",
    "post_logout_redirect_uri": "post_logout_redirect_uris",
}

# OIDC
RP_URI_CLAIMS = ["policy_uri", "logo_uri", "tos_uri", "initiate_login_uri",
                 "post_logout_redirect_uri", "frontchannel_logout_uri",
                 "backchannel_logout_uri", "client_uri"]
# OAUTH2
CLIENT_URI_CLAIMS = ["jwks_uri", "client_uri", "logo_uri", "tos_uri", "policy_uri"]


def supported_to_preferred(
        supported: dict,
        preference: dict,
        base_url: str,
        info: Optional[dict] = None,
):
    if info:  # The provider info
        for key, val in supported.items():
            if key in preference:
                _pref_val = preference.get(key)  # defined in configuration
                _info_val = info.get(key)
                if _info_val:
                    if isinstance(_info_val, bool):
                        if _info_val is False and _pref_val is True:
                            # Turn off support if server doesn't support
                            preference[key] = _info_val
                    else:
                        # Only use provider setting if less or equal to what I support
                        if key.endswith("supported"):  # list
                            preference[key] = [x for x in _pref_val if x in _info_val]
                        else:
                            pass
            elif val is None:  # No default, means the RP does not have a preference
                # if key not in ['jwks_uri', 'jwks']:
                pass
            else:
                # there is a default
                _info_val = info.get(key)
                if _info_val:  # The OP has an opinion
                    if key.endswith("supported"):  # list
                        preference[key] = [x for x in val if x in _info_val]
                    else:
                        pass
                elif val:
                    preference[key] = val

        # special case -> must have a request_uris value
        if "require_request_uri_registration" in info:
            # only makes sense if I want to use request_uri
            if preference.get("request_parameter") == "request_uri":
                if "request_uri" not in preference:
                    preference["request_uris"] = [f"{base_url}/requests"]
            else:  # just ignore
                logger.info('Asked for "request_uri" which it did not plan to use')
    else:
        # Add defaults
        for key, val in supported.items():
            if val is None:
                continue
            if key not in preference:
                preference[key] = val

    return preference


def array_or_singleton(claim_spec, values):
    if isinstance(claim_spec[0], list):
        if isinstance(values, list):
            return values
        else:
            return [values]
    else:
        if isinstance(values, list):
            return values[0]
        else:  # singleton
            return values


def _is_subset(a, b):
    # Is 'a' a subset of 'b'
    if isinstance(a, list):
        if isinstance(b, list):
            return set(a).issubset(set(b))
    elif isinstance(b, list):
        return a in b
    else:
        return a == b


def _intersection(a, b):
    res = None
    if isinstance(a, list):
        if isinstance(b, list):
            res = list(set(a).intersection(set(b)))
        else:
            if b in a:
                res = b
            else:
                res = []
    elif isinstance(b, list):
        if a in b:
            res = [a]
        else:
            res = []
    return res


def preferred_to_registered(
        prefers: dict,
        supported: dict,
        registration_response: Optional[dict] = None,
        uri_claims: Optional[list] = None,
        register2preferred: Optional[dict] = REGISTER2PREFERRED,
        metadata_class: Optional[Message] = RegistrationResponse
):
    """
    The claims with values that are returned from the OP is what goes unless (!!)
    the values returned are not within the supported values.

    @param prefers:
    @param registration_response:
    @return:
    """
    registered = {}

    if registration_response:
        for key, val in registration_response.items():
            if uri_claims and key in uri_claims:
                registered[key] = val
                continue

            if key in register2preferred:
                _sp_key = register2preferred[key]
                _allow = prefers.get(_sp_key)
                if not _allow:
                    _allow = supported.get(_sp_key)
                    if not _allow:
                        continue

                # Is the response value with in what this instance supports
                if _is_subset(val, _allow):
                    registered[key] = val
                else:
                    logger.warning(
                        f"OP tells me to do something I do not allow: '{key}' value '{val}' not within '{_allow}'"
                    )
                    _val = _intersection(val, _allow)
                    if _val:
                        registered[key] = _val
                    else:
                        raise ValueError(f"Not able to support the OPs choice: {key}={val}")
            else:
                registered[key] = val  # Should I just accept with the OP says ??

    for key, spec in metadata_class.c_param.items():
        if key in registered:
            continue
        _supported_key = register2preferred.get(key, key)

        _preferred_values = prefers.get(key, prefers.get(_supported_key))
        if not _preferred_values:
            continue

        registered[key] = array_or_singleton(spec, _preferred_values)

    preferred2register = dict([(v, k) for k, v in register2preferred.items()])

    # transfer those claims that are not part of the registration request
    _rr_keys = list(metadata_class.c_param.keys())
    for key, val in prefers.items():
        _reg_key = preferred2register.get(key, key)
        if _reg_key not in _rr_keys:
            # If they are not part of the registration request I do not knoe if it is supposed to
            # be a singleton or an array. So just add it as is.
            registered[_reg_key] = val

    logger.debug(f"preferred2registered: {registered}")
    return registered


def create_registration_request(prefers: dict, supported: dict) -> dict:
    _request = {}
    for key, spec in RegistrationRequest.c_param.items():
        _pref_key = REGISTER2PREFERRED.get(key, key)
        if _pref_key in prefers:
            value = prefers[_pref_key]
        elif _pref_key in supported:
            value = supported[_pref_key]
        else:
            continue

        if not value:
            continue

        _request[key] = array_or_singleton(spec, value)

    for key, val in prefers.items():
        if key not in RegistrationRequest.c_param.keys():
            if key not in REGISTER2PREFERRED.values():
                _request[key] = val

    return _request
