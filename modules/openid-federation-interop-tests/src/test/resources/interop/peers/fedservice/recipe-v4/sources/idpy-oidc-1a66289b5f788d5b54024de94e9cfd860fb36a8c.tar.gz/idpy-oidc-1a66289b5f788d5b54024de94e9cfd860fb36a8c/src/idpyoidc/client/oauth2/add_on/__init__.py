from idpyoidc.client.util import importer


def do_add_ons(context, add_ons, services):
    for key, spec in add_ons.items():
        _func = importer(spec["function"])
        _func(context, services, **spec["kwargs"])
